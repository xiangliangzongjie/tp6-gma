<?php
namespace app\model;
use think\Model;
class Casestudy extends Model{
}
?>