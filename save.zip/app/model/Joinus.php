<?php
namespace app\model;
use think\Model;
class Joinus extends Model{

}
?>